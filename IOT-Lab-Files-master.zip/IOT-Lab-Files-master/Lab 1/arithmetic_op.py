
# Date = 09-01

a = int(input("Enter the first number: "))
b = int(input("Enter the secound number: "))

# op = input("Enter:- + : addition, - : substraction, * : multiplication, / : division, % : mod ")

print("Addition of {} and {} is: " .format(a, b), a+b)
print("Substraction of {} and {} is: " .format(a, b), a-b)
print("Multiplication of {} and {} is: " .format(a, b), a*b)
print("Division of {} and {} is: " .format(a, b), a/b)
print("Mod of {} and {} is: " .format(a, b), a % b)
