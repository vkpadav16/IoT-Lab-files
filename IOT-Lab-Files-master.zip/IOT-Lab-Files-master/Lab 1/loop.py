# For loop

a = int(input("Enter the number: "))

addition = 0

for j in range(a + 1):
    addition = addition + j

print(addition)


# While loop
k = 1
addition1 = 0
while (k <= a):
    addition1 = addition1 + k
    k = k + 1

print(addition1)
